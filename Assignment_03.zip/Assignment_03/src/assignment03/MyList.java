
package assignment03;

import java.util.ArrayList;
import java.util.TreeMap;


public class MyList{
    
    public static TreeMap<String,Patient> ml;
    public static void load()
    {
        ml = new TreeMap<>();
    }
}
